#!/bin/sh

autoreconf -f -i -I "$(pwd)"/m4
exit $?
