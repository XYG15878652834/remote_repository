//头文件
#include<linux/module.h>//包含初始化加载模块的头文件
#include<linux/init.h>//包含宏定义的头文件
//功能
static int helloworld_init(void)//驱动加载函数
{
    printk("hello world\n");
    return 0;
}
static void helloworld_exit(void)//驱动卸载函数
{
    printk("hello world bye\n");
}
//驱动模块的入口和出口
module_init(helloworld_init);
module_exit(helloworld_exit);
//声明模块拥有开源许可证
MODULE_LICENSE("GPL");//模块许可证，避免警告
MODULE_AUTHOR("XYG");//作者
MODULE_VERSION("V1.0");//版本信息
MODULE_DESCRIPTION("A simple hello world linux driver");//描述