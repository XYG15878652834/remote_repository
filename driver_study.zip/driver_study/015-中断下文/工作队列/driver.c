#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/workqueue.h>
#include <linux/slab.h>

// 定义工作队列的工作结构
static struct workqueue_struct *my_wq;
static struct work_struct my_work;

// 工作队列的处理函数
void my_work_handler(struct work_struct *work)
{
    pr_info("Workqueue handler ok\n");
}

// 模块初始化函数
static int __init workqueue_example_init(void)
{
    pr_info("Workqueue example module ok\n");
    // 创建一个工作队列
    my_wq = create_workqueue("my_workqueue");
    if (!my_wq) {
        pr_err("Failed to create workqueue\n");
        return -ENOMEM;
    }
    // 初始化工作结构
    INIT_WORK(&my_work, my_work_handler);
    // 将工作项调度到工作队列
    pr_info("Scheduling work to the workqueue\n");
    queue_work(my_wq, &my_work);
    return 0;
}

// 模块卸载函数
static void __exit workqueue_example_exit(void)
{
    pr_info("Workqueue example module bye\n");
    // 等工作队列中的所有任务完成
    flush_workqueue(my_wq);
    // 销毁工作队列
    destroy_workqueue(my_wq);
}

// 定义模块的初始化和卸载函数
module_init(workqueue_example_init);
module_exit(workqueue_example_exit);

// 模块信息
MODULE_LICENSE("GPL");
MODULE_AUTHOR("XYG");
MODULE_DESCRIPTION("A simple Linux workqueue example.");

