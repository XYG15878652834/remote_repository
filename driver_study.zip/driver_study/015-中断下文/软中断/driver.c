#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/slab.h>
#include <linux/irq.h>

// 定义软中断编号0
static int  MY_SOFTIRQ = 0;

// 软中断处理函数
void my_softirq_handler(struct softirq_action *action)
{
    printk("my_softirq_handler is ok\n");
}

// 模块加载时调用的函数
static int __init softirq_example_init(void)//extern void softirq_init(void);不能使用softirq_init
{
    printk("SoftIRQ  module init\n");
    open_softirq(MY_SOFTIRQ, my_softirq_handler);// 初始化软中断
    printk("Raising softirq\n");// 触发软中断
    raise_softirq(MY_SOFTIRQ);
    return 0;
}

// 模块卸载时调用的函数
static void __exit softirq_example_exit(void)
{
    raise_softirq_irqoff(MY_SOFTIRQ);
    printk("SoftIRQ  module exit and my softirq %d freed\n",MY_SOFTIRQ);
}

// 定义模块的出口和入口函数
module_init(softirq_example_init);
module_exit(softirq_example_exit);

// 模块信息
MODULE_LICENSE("GPL");
MODULE_AUTHOR("XYG");
MODULE_DESCRIPTION("A simple Linux SoftIRQ example.");

