#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/slab.h>

// 定义 Tasklet 结构
static struct tasklet_struct my_tasklet;

// Tasklet 的处理函数
void my_tasklet_handler(unsigned long data)
{
    pr_info("My Tasklet handler executed, data = %lu\n", data);
}

// 模块初始化函数
static int __init tasklet_example_init(void)
{
    pr_info("Tasklet example module hello\n");

    // 初始化 Tasklet
    tasklet_init(&my_tasklet, my_tasklet_handler, 1234);

    // 启动 Tasklet
    pr_info("Scheduling Tasklet\n");
    tasklet_schedule(&my_tasklet);

    return 0;
}

// 模块卸载函数
static void __exit tasklet_example_exit(void)
{
    pr_info("Tasklet example module bye\n");

    // 关闭 Tasklet
    tasklet_kill(&my_tasklet);
}

// 定义模块的初始化和卸载函数
module_init(tasklet_example_init);
module_exit(tasklet_example_exit);

// 模块信息
MODULE_LICENSE("GPL");
MODULE_AUTHOR("XYG");
MODULE_DESCRIPTION("A simple Linux Tasklet example.");

