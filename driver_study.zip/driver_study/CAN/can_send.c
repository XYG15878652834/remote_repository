#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<linux/can/raw.h>
#include<string.h>
#include<net/if.h>
#include<sys/ioctl.h>
#include<unistd.h>

int main(int argc,char *argv[])
{
    int s;
    int ret;
    struct sockaddr_can addr;
    struct ifreq ifr;
    struct can_frame frame[3];
    unsigned char data[2] ={0x01,0x02};
    //标准帧
    frame[0].can_id = 0x11;
    frame[0].can_dlc = 2;
    strcpy(frame[0].data,data);
    //扩展帧
    frame[1].can_id = 0x11 | CAN_EFF_FLAG;
    frame[1].can_dlc = 2;
    strcpy(frame[1].data,data);
    //遥控帧
    frame[2].can_id = 0x11 | CAN_RTR_FLAG;
    frame[2].can_dlc = 2;

    s = socket(PF_CAN,SOCK_RAW,CAN_RAW);
    if(s < 0)
    {
        printf("socket create error\n");
        return -1;
    }

    strcpy(ifr.ifr_name,"can0");
    ioctl(s,SIOGIFINDEX,&ifr);

    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;

    bind(s,(struct sockaddr *)&addr,sizeof(addr));
    while(1)
    {
        ret = write(s,&frame[0],sizeof(frame[0]));
        if(ret != sizeof(frame[0]))
        {
            printf("send frame[0] error\n");
            break;
        }
        ret = write(s,&frame[1],sizeof(frame[1]));
        if(ret != sizeof(frame[1]))
        {
            printf("send frame[1] error\n");
            break;
        }
        ret = write(s,&frame[2],sizeof(frame[2]));
        if(ret != sizeof(frame[2]))
        {
            printf("send frame[2] error\n");
            break;
        }
    }
    close(s);
    return 0;
}