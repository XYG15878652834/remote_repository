#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/interrupt.h>
#include <linux/gpio.h>
#include <linux/io.h>
#include <linux/init.h>
#include <linux/platform_device.h>
#include <linux/irq.h>

// 定义中断号（IRQ编号）是 20
static int  MY_IRQ = 20;

// 中断处理函数
static irqreturn_t my_irq_handler(int irq, void *dev_id)
{
    // 在此处处理硬件中断
    printk( "my_irq_handler Interrupt %d is ok\n", MY_IRQ);
    // 返回IRQ_HANDLED表示中断已被处理
    return IRQ_HANDLED;
}

// 初始化模块时请求中断
static int __init my_module_init(void)
{
    int ret;
    // 注册中断处理程序
    ret = request_irq(MY_IRQ,          // IRQ号
                      my_irq_handler,  // 中断处理函数
                      IRQF_SHARED,     // 标记中断共享，表示多个设备可以使用同一个中断
                      "my_irq_handler", // 中断名称
                      NULL);           // 设备特定数据
    if (ret) {
        printk( "request_irq error");
        return ret;
    }
    printk( "Module init and IRQ %d requested\n", MY_IRQ);
    return 0;
}

// 卸载模块时释放中断
static void __exit my_module_exit(void)
{
    // // 释放中断
    // free_irq(MY_IRQ, NULL);
    printk("Module exit and IRQ %d freed\n", MY_IRQ);
}

module_init(my_module_init);  // 模块初始化函数
module_exit(my_module_exit);  // 模块退出函数

MODULE_LICENSE("GPL");
MODULE_AUTHOR("XYG");
MODULE_DESCRIPTION("Simple Interrupt Example");

