#include<linux/init.h>
#include<linux/module.h>
#include<linux/spi/spi.h>
#include<linux/cdev.h>
#include<linux/fs.h>
#include<linux/kdev_t.h>
#include<linux/spi/spi.h>

#define CNF1 0X2a
dev_t dev_num;
struct cdev mcp2515_cdev;
struct class *mcp2515_class;
struct device *mcp2515_device;
struct spi_device *spi_dev;

void mcp2515_reset(void)
{
    int ret;
    char write_buf[] = {0xc0};
    ret = spi_write(spi_dev,write_buf,sizeof(write_buf));
    if(ret < 0)
    {
        printk("spi_write is error\n");
    }    
}
char mcp2515_read_reg(char reg)
{
    char write_buf[]= {0x03,reg};
    char read_buf;
    int ret;
    ret = spi_write_then_read(spi_dev,write_buf,sizeof(write_buf),&read_buf,sizeof(read_buf));
    if(ret < 0)
    {
        printk("spi_write_then_read is error\n");
    }
    return read_buf;
}
int mcp2515_open(struct inode *inode,struct file *file)
{
    return 0;
}
ssize_t mcp2515_read(struct file *file, char __user *ubuf, size_t size, loff_t *loff_t)
{
	printk("mcp2515_read\n");
	return 0;
}
ssize_t mcp2515_write(struct file *file, const char __user *ubuf, size_t size, loff_t *loff_t)
{
	printk("mcp2515_write\n");
	return 0;
}
int mcp2515_release(struct inode *inode,struct file *file)
{
    return 0;
}
struct file_operations mcp2515_fops = {
    .open = mcp2515_open,
    .read = mcp2515_read,
    .write = mcp2515_write,
    .release = mcp2515_release,
};

int mcp2515_probe(struct spi_device *spi)
{
    int ret;
    char value;
    printk("This is mcp2515_probe\n");
    spi_dev = spi;
    ret = alloc_chrdev_region(&dev_num,0,1,"mcp2515");
    if(ret < 0)
    {
        printk("alloc_chrdev_region error\n");
        return -1;
    }
    cdev_init(&mcp2515_cdev,&mcp2515_fops);
    mcp2515_cdev.owner = THIS_MODULE;
    ret = cdev_add(&mcp2515_cdev,dev_num,1);
    if(ret < 0)
    {
        printk("cdev_add error\n");
        return -1;
    }
    mcp2515_class = class_create(THIS_MODULE,"spi_to_can");
    if(IS_ERR(mcp2515_class))
    {
        printk("class_create error\n");
        return PTR_ERR(mcp2515_class);
    }
    mcp2515_device = device_create(mcp2515_class,NULL,dev_num,NULL,"mcp2515");
    if(IS_ERR(mcp2515_device))
    {
        printk("class_create error\n");
        return PTR_ERR(mcp2515_device);
    }
    mcp2515_reset();
    value = mcp2515_read_reg(0x0e);
    printk("value is %x\n",value);
    return 0;
}
int mcp2515_remove(struct spi_device *spi)
{
    printk("This is mcp2515_remove\n");
    return 0;
}

const struct of_device_id mcp2515_of_match_table[] = {
    {.compatible = "my-mcp2515"},
    {}
};

const struct spi_device_id mcp2515_id_table[] = {
    {"mcp2515"},
    {}
};

struct spi_driver spi_mcp2515 = {
    .probe = mcp2515_probe,
    .remove = mcp2515_remove,
    .driver = {
        .name = "mcp2515",
        .owner = THIS_MODULE,
        .of_match_table = mcp2515_of_match_table,
    },
    .id_table = mcp2515_id_table,
};

static int __init mcp2515_init(void)
{
    int ret;
    ret = spi_register_driver(&spi_mcp2515);
    if(ret < 0)
    {
        printk("spi_register_driver error\n");
        return ret;
    }
    return ret;
}

static void __exit mcp2515_exit(void)
{
    device_destroy(mcp2515_class,dev_num);
    class_destroy(mcp2515_class);
    cdev_del(&mcp2515_cdev);
    unregister_chrdev_region(dev_num,1);
    spi_unregister_driver(&spi_mcp2515);
}

module_init(mcp2515_init);
module_exit(mcp2515_exit);
//声明模块拥有开源许可证
MODULE_LICENSE("GPL");//模块许可证，避免警告
MODULE_AUTHOR("XYG");//作者
MODULE_VERSION("V1.0");//版本信息
MODULE_DESCRIPTION("A simple SPI linux driver");//描述